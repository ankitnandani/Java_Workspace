package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        // Load the Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");

        // Retrieve the studentList bean
        @SuppressWarnings("unchecked")
		List<Student> studentList = (List<Student>) context.getBean("studentList");

        // Print the student information
        for (Student student : studentList) {
            System.out.println(student);
        }
    }
}