package com.mkyong.common;

public class Person 
{
	private String name;
	private String address;
	private int age;
	
	@Override
	public String toString()
	{
		return "Person [address=" + address + ", age=" + age + ", name=" + name + "]";
	}	
}