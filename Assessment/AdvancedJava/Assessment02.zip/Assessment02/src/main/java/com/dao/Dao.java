package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Model;

public class Dao 
{

	public static Connection getconnect()
	{
		Connection con = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/assessment02","root","");
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	public static int savedata(Model m)
	{
		int status =0;
		Connection con = Dao.getconnect();
		
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert into details (pname,pcategory,pmodel,pprice,pdesc,pimage) values (?,?,?,?,?,?)");
			ps.setString(1,m.getPname());
			ps.setString(2,m.getPcategory());
			ps.setString(3,m.getPmodel());
			ps.setString(4,m.getPprice());
			ps.setString(5,m.getPdesc());
			ps.setString(6,m.getPimage());
			
			status = ps.executeUpdate();
		
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
		
	}
	
	public static List<Model> viewdata()
	{
		List<Model> list= new ArrayList<Model>();
		
		Connection con = Dao.getconnect();
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from details");	
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				int id = rs.getInt(1);
				String pname = rs.getString(2);
				String pcategory = rs.getString(3);
				String pmodel = rs.getString(4);
				String pprice = rs.getString(5);
				String pdesc = rs.getString(6);
				String pimage = rs.getString(7);
				
				Model m = new Model();
				
				m.setId(id);
				m.setPname(pname);
				m.setPcategory(pcategory);
				m.setPmodel(pmodel);
				m.setPprice(pprice);
				m.setPdesc(pdesc);
				m.setPimage(pimage);
				
				list.add(m);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return list;
	}
	
	public static Model getsingledata(String id)
	{
		Connection con = Dao.getconnect();
		
		Model m = null;
		
		PreparedStatement ps;
		try
		{
			ps=con.prepareStatement("select * from details where id=?;");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				m= new Model();
				m.setId(rs.getInt(1));
				m.setPname(rs.getString(2));
				m.setPcategory(rs.getString(3));
				m.setPmodel(rs.getString(4));
				m.setPprice(rs.getString(5));
				m.setPdesc(rs.getString(6));
				m.setPimage(rs.getString(7));
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return m;
	}
	
	public static int updatedata(Model m)
	{
		Connection con = Dao.getconnect();
		
		int status = 0;
		
		PreparedStatement ps;
		
		try 
		{
			ps = con.prepareStatement("update details set pname=?, pcategory=?, pmodel=? , pprice=? , pdesc=? , pimage=? where id = ?");
			ps.setString(1,m.getPname());
			ps.setString(2,m.getPcategory());
			ps.setString(3,m.getPmodel());
			ps.setString(4,m.getPprice());
			ps.setString(5,m.getPdesc());
			ps.setString(6,m.getPimage());
			ps.setInt(7, m.getId());
			
			status = ps.executeUpdate();
		
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
	public static int deletefromid(String id)
	{
		int status = 0;
		
		Connection con = Dao.getconnect();
		
		PreparedStatement ps;
		try
		{
			ps=con.prepareStatement("delete from details where id = ?;");
			ps.setString(1, id);
			
			status=ps.executeUpdate();
		}
		catch(Exception e)
		{
			
		}
		
		return status;
	}
}
