import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.dao.Dao;
import com.model.Model;

@MultipartConfig
@WebServlet("/upload")
public class AddServlet extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		Model m = new Model();
		m.setPname(req.getParameter("pname"));
		m.setPcategory(req.getParameter("pcategory"));
		m.setPmodel(req.getParameter("pmodel"));
		m.setPprice(req.getParameter("pprice"));
		m.setPdesc(req.getParameter("pdesc"));
		
		Part filePart = req.getPart("pimage");
		m.setPimage(getSubmittedFileName(filePart));
		
		String path = "/Users/ankitnandani/eclipse-workspace/Assessment02/src/main/webapp/uploads";
		String fileName=getSubmittedFileName(filePart);
		
		OutputStream otpStream = null;  
        InputStream iptStream = null;  
        
        try 
        {  
            
            otpStream = new FileOutputStream(new File(path + File.separator + fileName));  
            iptStream = filePart.getInputStream();  
  
            int read = 0;  
              

            final byte[] bytes = new byte[1024];  
              
              
            while ((read = iptStream.read(bytes)) != -1) {  
                otpStream.write(bytes, 0, read);  
            }
        }
        catch(Exception e)
        {
        	System.out.println(e.getStackTrace());
        }
        finally
        {
        	 if (otpStream != null) {  
                 otpStream.close();  
             }  
             if (iptStream != null) {  
                 iptStream.close();  
             }  
        }
        

		
		int data = Dao.savedata(m);
		
		if(data>0)
		{
			resp.sendRedirect("index.jsp");
		}
	}
	
	private static String getSubmittedFileName(Part part) {
	    for (String cd : part.getHeader("content-disposition").split(";")) {
	        if (cd.trim().startsWith("filename")) {
	            String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
	            return fileName.substring(fileName.lastIndexOf('/') + 1).substring(fileName.lastIndexOf('\\') + 1); // MSIE fix.
	        }
	    }
	    return null;
	}
	


}
